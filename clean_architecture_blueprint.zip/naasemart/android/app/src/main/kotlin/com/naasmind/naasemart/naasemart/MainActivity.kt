package com.naasmind.naasemart.naasemart

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()

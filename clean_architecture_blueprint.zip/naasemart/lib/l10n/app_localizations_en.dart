// ignore: unused_import
import 'package:intl/intl.dart' as intl;
import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for English (`en`).
class AppLocalizationsEn extends AppLocalizations {
  AppLocalizationsEn([String locale = 'en']) : super(locale);

  @override
  String get demoProductsTitle => 'Demo Products';

  @override
  String get loadProducts => 'Load Demo Products';

  @override
  String get noProducts => 'No products found';

  @override
  String get retry => 'Retry';

  @override
  String copyright(Object year) {
    return '© All rights reserved Naasmind $year';
  }

  @override
  String get helloThere => 'Hello There 👋';

  @override
  String get loginSubtitle =>
      'Please enter your email & password to access your account.';

  @override
  String get email => 'Email';

  @override
  String get password => 'Password';

  @override
  String get confirmPassword => 'Confirm Password';

  @override
  String get lastName => 'Last Name';

  @override
  String get firstName => 'First Name';

  @override
  String get forgotPassword => 'Forgot Password';

  @override
  String get login => 'Login';

  @override
  String get newHere => 'New here? Create An Account. ';

  @override
  String get signUp => 'Sign Up';

  @override
  String get hintFirstName => 'Enter first name';

  @override
  String get hintLastName => 'Enter last name';

  @override
  String get hintEmail => 'ex: name@yogam.com';

  @override
  String get hintPassword => '*****';

  @override
  String get hintConfirmPassword => '*****';

  @override
  String get errFirstNameRequired => 'Enter first name';

  @override
  String get errLastNameRequired => 'Enter last name';

  @override
  String get errEmailRequired => 'Email required';

  @override
  String get errEmailInvalid => 'Enter valid email';

  @override
  String get errPasswordRequired => 'Password required';

  @override
  String get errPasswordMin => 'Minimum 6 characters';

  @override
  String get errConfirmPasswordRequired => 'Confirm password required';

  @override
  String get errPasswordNotMatch => 'Passwords don’t match';

  @override
  String get agreePrefix => 'I agree to the ';

  @override
  String get termsOfService => 'Terms of Service';

  @override
  String get alreadyHaveAccount => 'Already have an account? ';

  @override
  String get alreadyRememberPassword => 'Already remember your Password';

  @override
  String get pleaseLogin => 'Please Login';

  @override
  String get next => 'Next';

  @override
  String get pleaseEnterEmail => 'Please enter Your Email.';

  @override
  String get otpWillSent => 'One OTP Will send to your Email.';

  @override
  String get placeOtp => 'Place OTP';

  @override
  String get pleasePlaceOtp => 'Please Enter your OTP.';

  @override
  String get otpSent => 'One OTP has send to your Email.';

  @override
  String get pleaseCreatePassword => 'Please Create New Password.';

  @override
  String get createPassword => 'Create New Password';

  @override
  String get yourEmail => 'Your Registered Email';
}

// ignore: unused_import
import 'package:intl/intl.dart' as intl;
import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for English (`en`).
class AppLocalizationsEn extends AppLocalizations {
  AppLocalizationsEn([String locale = 'en']) : super(locale);

  @override
  String get demoProductsTitle => 'Demo Products';

  @override
  String get loadProducts => 'Load Demo Products';

  @override
  String get noProducts => 'No products found';

  @override
  String get retry => 'Retry';
}

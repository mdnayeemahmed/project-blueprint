// ignore: unused_import
import 'package:intl/intl.dart' as intl;
import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for Bengali Bangla (`bn`).
class AppLocalizationsBn extends AppLocalizations {
  AppLocalizationsBn([String locale = 'bn']) : super(locale);

  @override
  String get demoProductsTitle => 'ডেমো পণ্যসমূহ';

  @override
  String get loadProducts => 'ডেমো পণ্য লোড করুন';

  @override
  String get noProducts => 'কোনো পণ্য পাওয়া যায়নি';

  @override
  String get retry => 'পুনরায় চেষ্টা করুন';
}

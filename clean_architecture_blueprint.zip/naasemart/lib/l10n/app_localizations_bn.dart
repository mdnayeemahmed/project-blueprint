// ignore: unused_import
import 'package:intl/intl.dart' as intl;
import 'app_localizations.dart';

// ignore_for_file: type=lint

/// The translations for Bengali Bangla (`bn`).
class AppLocalizationsBn extends AppLocalizations {
  AppLocalizationsBn([String locale = 'bn']) : super(locale);

  @override
  String get demoProductsTitle => 'ডেমো পণ্যসমূহ';

  @override
  String get loadProducts => 'ডেমো পণ্য লোড করুন';

  @override
  String get noProducts => 'কোনো পণ্য পাওয়া যায়নি';

  @override
  String get retry => 'পুনরায় চেষ্টা করুন';

  @override
  String copyright(Object year) {
    return '© সর্বস্বত্ব সংরক্ষিত Naasmind $year';
  }

  @override
  String get helloThere => 'হ্যালো 👋';

  @override
  String get loginSubtitle =>
      'আপনার অ্যাকাউন্টে প্রবেশ করতে ইমেইল ও পাসওয়ার্ড দিন।';

  @override
  String get email => 'ইমেইল';

  @override
  String get password => 'পাসওয়ার্ড';

  @override
  String get confirmPassword => 'পাসওয়ার্ড নিশ্চিত করুন';

  @override
  String get lastName => 'নামের শেষ অংশ';

  @override
  String get firstName => 'নামের প্রথম অংশ';

  @override
  String get forgotPassword => 'পাসওয়ার্ড ভুলে গেছেন?';

  @override
  String get login => 'লগইন';

  @override
  String get newHere => 'নতুন এখানে? অ্যাকাউন্ট তৈরি করুন। ';

  @override
  String get signUp => 'সাইন আপ';

  @override
  String get hintFirstName => 'প্রথম নাম লিখুন';

  @override
  String get hintLastName => 'শেষ নাম লিখুন';

  @override
  String get hintEmail => 'যেমন: name@yogam.com';

  @override
  String get hintPassword => '*****';

  @override
  String get hintConfirmPassword => '*****';

  @override
  String get errFirstNameRequired => 'প্রথম নাম লিখুন';

  @override
  String get errLastNameRequired => 'শেষ নাম লিখুন';

  @override
  String get errEmailRequired => 'ইমেইল দিতে হবে';

  @override
  String get errEmailInvalid => 'সঠিক ইমেইল দিন';

  @override
  String get errPasswordRequired => 'পাসওয়ার্ড দিতে হবে';

  @override
  String get errPasswordMin => 'কমপক্ষে ৬ অক্ষর হতে হবে';

  @override
  String get errConfirmPasswordRequired => 'পাসওয়ার্ড নিশ্চিত করুন';

  @override
  String get errPasswordNotMatch => 'দুইটি পাসওয়ার্ড মেলেনি';

  @override
  String get agreePrefix => 'আমি সম্মত ';

  @override
  String get termsOfService => 'সেবার শর্তাবলীতে';

  @override
  String get alreadyHaveAccount => 'আগে থেকেই অ্যাকাউন্ট আছে? ';

  @override
  String get alreadyRememberPassword => 'আপনি কি আগেই পাসওয়ার্ড মনে রেখেছেন?';

  @override
  String get pleaseLogin => 'অনুগ্রহ করে লগইন করুন';

  @override
  String get next => 'পরবর্তী';

  @override
  String get pleaseEnterEmail => 'অনুগ্রহ করে আপনার ইমেইল দিন।';

  @override
  String get otpWillSent => 'একটি OTP আপনার ইমেইলে পাঠানো হবে।';

  @override
  String get placeOtp => 'OTP দিন';

  @override
  String get pleasePlaceOtp => 'অনুগ্রহ করে OTP লিখুন।';

  @override
  String get otpSent => 'একটি OTP আপনার ইমেইলে পাঠানো হয়েছে।';

  @override
  String get pleaseCreatePassword => 'অনুগ্রহ করে নতুন পাসওয়ার্ড তৈরি করুন।';

  @override
  String get createPassword => 'নতুন পাসওয়ার্ড তৈরি করুন';

  @override
  String get yourEmail => 'আপনার নিবন্ধিত ইমেইল';
}

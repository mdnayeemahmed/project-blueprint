import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:naasemart/core/constants/asset_paths.dart';
import 'package:naasemart/core/utils/extension.dart';
import 'package:naasemart/core/widgets/app_text_input_field.dart';
import 'package:naasemart/feature/forgotPassword/presentation/pages/forgot_password_screen.dart';
import 'package:naasemart/feature/signup/presentation/pages/sign_up_screen.dart';

class LoginScreen extends StatefulWidget {
  static const String name = '/login';

  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final TextEditingController emailController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.start,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              SizedBox(height: 20.h),

              Text(
                context.strings.helloThere,
                style: TextStyle(fontSize: 16.sp, fontWeight: FontWeight.w500),
              ),

              SizedBox(height: 15.h),

              Text(
                context.strings.loginSubtitle,
                style: TextStyle(fontSize: 12.sp, fontWeight: FontWeight.w400),
              ),

              SizedBox(height: 40.h),
              AppTextInputField(
                controller: emailController,
                label: context.strings.email,
                hint: context.strings.hintEmail,
                keyboardType: TextInputType.emailAddress,
                validator: (v) {
                  final value = (v ?? "").trim();
                  if (value.isEmpty) return context.strings.errEmailRequired;
                  if (!value.contains("@")) {
                    return context.strings.errEmailInvalid;
                  }
                  return null;
                },
              ),

              SizedBox(height: 16.h),

              AppTextInputField(
                controller: passwordController,
                label: context.strings.password,
                hint: context.strings.hintPassword,
                obscureText: true,
                validator: (v) {
                  final value = (v ?? "");
                  if (value.isEmpty) return context.strings.errPasswordRequired;
                  if (value.length < 6) return context.strings.errPasswordMin;
                  return null;
                },
              ),

              SizedBox(height: 15.h),
              GestureDetector(
                onTap: (){
                  Navigator.pushNamed(context, ForgotPasswordScreen.name);

                },
                child: SizedBox(
                  width: double.infinity,
                  child: Text(
                    context.strings.forgotPassword,
                    textAlign: TextAlign.end,
                    style: TextStyle(
                      fontSize: 14.sp,
                      fontWeight: FontWeight.w500,
                      color: context.color.primary,
                    ),
                  ),
                ),
              ),
              SizedBox(height: 15.h),
              SizedBox(
                width: double.infinity,
                height: 50.h,
                child: ElevatedButton(
                  onPressed: () {},
                  child: Text(context.strings.login),
                ),
              ),
              SizedBox(height: 30.h),

              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Image.asset(AssetPaths.googleButton, height: 52.h),
                  SizedBox(width: 10.w),
                  Image.asset(AssetPaths.appleButton, height: 50.h),
                ],
              ),
            ],
          ),
        ),
      ),
      bottomNavigationBar: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: GestureDetector(
            onTap: () {
              Navigator.pushNamed(context, SignUpScreen.name);
            },
            child: SizedBox(
              width: double.infinity,
              child: RichText(
                textAlign: TextAlign.center,
                text: TextSpan(
                  children: [
                    TextSpan(
                      text: context.strings.newHere,
                      style: TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.w400,
                        color: context.color.textPrimary,
                      ),
                    ),
                    TextSpan(
                      text: context.strings.signUp,
                      style: TextStyle(
                        color: Theme.of(context).primaryColor,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

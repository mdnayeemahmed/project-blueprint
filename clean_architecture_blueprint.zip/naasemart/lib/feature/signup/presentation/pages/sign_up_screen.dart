import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:naasemart/core/constants/app_strings.dart';
import 'package:naasemart/core/constants/app_valuenotifier.dart';
import 'package:naasemart/core/utils/extension.dart';
import 'package:naasemart/core/widgets/app_bar_widget.dart';
import 'package:naasemart/core/widgets/app_text_input_field.dart';
import 'package:naasemart/feature/demo/presentation/bloc/demo_product_bloc.dart';
import 'package:naasemart/feature/login/presentation/pages/login_screen.dart';


class SignUpScreen extends StatefulWidget {
  static const String name = '/signUp';

  const SignUpScreen({super.key});

  @override
  State<SignUpScreen> createState() => _SignUpScreenState();
}

class _SignUpScreenState extends State<SignUpScreen> {
  final _formKey = GlobalKey<FormState>();

  final TextEditingController firstNameController = TextEditingController();
  final TextEditingController lastNameController = TextEditingController();
  final TextEditingController emailController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();
  final TextEditingController confirmPasswordController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: true,
      appBar: AppBackTitleBar(
        title: context.strings.signUp, // ✅ localized
      ),
      body: SafeArea(
        child: Form(
          key: _formKey,
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [

                AppTextInputField(
                  controller: firstNameController,
                  label: context.strings.firstName,
                  hint: context.strings.hintFirstName,
                  validator: (v) =>
                  (v == null || v.trim().isEmpty)
                      ? context.strings.errFirstNameRequired
                      : null,
                ),

                SizedBox(height: 16.h),

                AppTextInputField(
                  controller: lastNameController,
                  label: context.strings.lastName,
                  hint: context.strings.hintLastName,
                  validator: (v) =>
                  (v == null || v.trim().isEmpty)
                      ? context.strings.errLastNameRequired
                      : null,
                ),

                SizedBox(height: 16.h),

                AppTextInputField(
                  controller: emailController,
                  label: context.strings.email,
                  hint: context.strings.hintEmail,
                  keyboardType: TextInputType.emailAddress,
                  validator: (v) {
                    final value = (v ?? "").trim();
                    if (value.isEmpty) return context.strings.errEmailRequired;
                    if (!value.contains("@")) return context.strings.errEmailInvalid;
                    return null;
                  },
                ),


                SizedBox(height: 16.h),

                AppTextInputField(
                  controller: passwordController,
                  label: context.strings.password,
                  hint: context.strings.hintPassword,
                  obscureText: true,
                  validator: (v) {
                    final value = (v ?? "");
                    if (value.isEmpty) return context.strings.errPasswordRequired;
                    if (value.length < 6) return context.strings.errPasswordMin;
                    return null;
                  },
                ),

                SizedBox(height: 16.h),

                AppTextInputField(
                  controller: confirmPasswordController,
                  label: context.strings.confirmPassword,
                  hint: context.strings.hintConfirmPassword,
                  obscureText: true,
                  validator: (v) {
                    final value = (v ?? "");
                    if (value.isEmpty) return context.strings.errConfirmPasswordRequired;
                    if (value != passwordController.text) return context.strings.errPasswordNotMatch;
                    return null;
                  },
                ),
                SizedBox(height: 16.h),

                ValueListenableBuilder<bool>(
                  valueListenable: agreeNotifier,
                  builder: (context, agree, _) {
                    return Row(
                      children: [
                        Checkbox(
                          value: agree,
                          onChanged: (v) => agreeNotifier.value = v ?? false,
                        ),
                        Expanded(
                          child: RichText(
                            text: TextSpan(
                              style: TextStyle(
                                fontSize: 14.sp,
                                color: Colors.black,
                              ),
                              children: [
                                TextSpan(text: context.strings.agreePrefix),
                                TextSpan(
                                  text: context.strings.termsOfService,
                                  style: TextStyle(
                                    color: Theme.of(context).primaryColor,
                                    fontWeight: FontWeight.w500,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    );
                  },
                ),

                SizedBox(height: 24.h),

                SizedBox(
                  width: double.infinity,
                  height: 50.h,
                  child: ElevatedButton(
                    onPressed: () {
                      if (_formKey.currentState!.validate()) {
                        // submit form
                      }
                    },
                    child: Text(context.strings.signUp),
                  ),
                ),

                SizedBox(height: 30.h),
              ],
            ),
          ),
        ),
      ),

      bottomNavigationBar: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: GestureDetector(
            onTap: () {
              Navigator.pushReplacementNamed(context, LoginScreen.name);
            },
            child: SizedBox(
              width: double.infinity,
              child: RichText(
                textAlign: TextAlign.center,
                text: TextSpan(
                  children: [
                    TextSpan(
                      text: context.strings.alreadyHaveAccount,
                      style: TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.w400,
                        color: context.color.textPrimary,
                      ),
                    ),
                    TextSpan(
                      text: context.strings.login,
                      style: TextStyle(
                        color: Theme.of(context).primaryColor,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}


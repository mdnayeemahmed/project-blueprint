import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:naasemart/core/constants/asset_paths.dart';
import 'package:naasemart/core/utils/extension.dart';
import 'package:naasemart/feature/login/presentation/pages/login_screen.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  static const String name = '/';

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    _moveToNextScreen();
  }

  Future<void> _moveToNextScreen() async {
    await Future.delayed(const Duration(seconds: 2));

    Navigator.pushReplacementNamed(context, LoginScreen.name);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        width: double.infinity,
        height: double.infinity,
        decoration: BoxDecoration(
          image: DecorationImage(
            image: AssetImage(AssetPaths.backgroundOne),
            fit: BoxFit.cover,
          ),
        ),
        child: SafeArea(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Spacer(),
              Image.asset(AssetPaths.naasmartLogoPng,height: 152.h,),
              Spacer(),
              Image.asset(AssetPaths.naasmindLogoPng,width: 94.w,),
              SizedBox(height: 10.h,),
              Text(context.strings.copyright(DateTime.now().year)),
            ],
          ),
        ), // add your UI here
      ),
    );
  }
}

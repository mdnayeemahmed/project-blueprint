import '../entities/demo_product.dart';


abstract class DemoProductRepository {
  Future<List<DemoProduct>> getProducts();
}

// GetDemoProductsUseCase
import 'package:naasemart/feature/demo/domain/entities/demo_product.dart';
import 'package:naasemart/feature/demo/domain/repository/demo_product_repository.dart';


class GetDemoProductsUseCase {
  final DemoProductRepository repository;

  const GetDemoProductsUseCase(this.repository);

  Future<List<DemoProduct>> call() => repository.getProducts();
}

import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:naasemart/core/constants/app_strings.dart';
import 'package:naasemart/feature/demo/presentation/bloc/demo_product_bloc.dart';


class DemoProductPage extends StatefulWidget {
  const DemoProductPage({super.key});

  @override
  State<DemoProductPage> createState() => _DemoProductPageState();
}

class _DemoProductPageState extends State<DemoProductPage> {
  @override
  void initState() {
    super.initState();

    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      context.read<DemoProductBloc>().add(const DemoProductEvent.load());
    });
  }

  Future<void> _reload() async {
    context.read<DemoProductBloc>().add(const DemoProductEvent.load());
  }

  @override
  Widget build(BuildContext context) {
    final s = AppStrings(context);

    return Scaffold(
      appBar: AppBar(title: Text(s.demoProductsTitle)),
      body: BlocBuilder<DemoProductBloc, DemoProductState>(
        builder: (context, state) {
          return state.when(
            initial: () => Center(
              child: ElevatedButton(
                onPressed: _reload,
                child: Text(s.loadProducts),
              ),
            ),

            loading: () =>
            const Center(child: CircularProgressIndicator()),

            success: (items) {
              if (items.isEmpty) {
                return RefreshIndicator(
                  onRefresh: _reload,
                  child: ListView(
                    physics: const AlwaysScrollableScrollPhysics(),
                    children: [
                      const SizedBox(height: 200),
                      Center(child: Text(s.noProducts)),
                    ],
                  ),
                );
              }

              return RefreshIndicator(
                onRefresh: _reload,
                child: ListView.separated(
                  physics: const AlwaysScrollableScrollPhysics(),
                  itemCount: items.length,
                  separatorBuilder: (_, __) =>
                  const Divider(height: 0),
                  itemBuilder: (_, i) {
                    final p = items[i];
                    return ListTile(
                      title: Text(p.name),
                      trailing: Text("\$${p.price}"),
                    );
                  },
                ),
              );
            },

            error: (message) => Center(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(message, textAlign: TextAlign.center),
                  const SizedBox(height: 12),
                  ElevatedButton(
                    onPressed: _reload,
                    child: Text(s.retry),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }


}

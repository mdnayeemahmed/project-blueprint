import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:naasemart/feature/demo/domain/entities/demo_product.dart';
import 'package:naasemart/feature/demo/domain/usecases/get_demo_products_usecase.dart';
import 'package:freezed_annotation/freezed_annotation.dart';

part 'demo_product_event.dart';
part 'demo_product_state.dart';
part 'demo_product_bloc.freezed.dart';



class DemoProductBloc extends Bloc<DemoProductEvent, DemoProductState> {
  final GetDemoProductsUseCase useCase;

  DemoProductBloc(this.useCase) : super(const DemoProductState.initial()) {
    on<_Load>(_onLoad);
  }

  Future<void> _onLoad(_Load event, Emitter<DemoProductState> emit) async {
    emit(const DemoProductState.loading());

    try {
      final items = await useCase();
      emit(DemoProductState.success(items));
    } catch (e) {
      emit(DemoProductState.error(e.toString()));
    }
  }
}

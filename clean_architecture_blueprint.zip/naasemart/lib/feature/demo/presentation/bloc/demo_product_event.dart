part of 'demo_product_bloc.dart';

@freezed
class DemoProductEvent with _$DemoProductEvent {
  const factory DemoProductEvent.load() = _Load;
}
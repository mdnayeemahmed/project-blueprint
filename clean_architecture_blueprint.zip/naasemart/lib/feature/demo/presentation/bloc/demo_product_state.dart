part of 'demo_product_bloc.dart';

@freezed
class DemoProductState with _$DemoProductState {
  const factory DemoProductState.initial() = _Initial;
  const factory DemoProductState.loading() = _Loading;
  const factory DemoProductState.success(List<DemoProduct> items) = _Success;
  const factory DemoProductState.error(String message) = _Error;
}

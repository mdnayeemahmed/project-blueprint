import 'package:naasemart/feature/demo/data/datasource/demo_product_remote_datasource.dart';
import 'package:naasemart/feature/demo/domain/entities/demo_product.dart';
import 'package:naasemart/feature/demo/data/models/demo_product_model.dart';
import 'package:naasemart/feature/demo/domain/repository/demo_product_repository.dart';

class DemoProductRepositoryImpl implements DemoProductRepository {
  final DemoProductRemoteDataSource remote;

  const DemoProductRepositoryImpl(this.remote);

  @override
  Future<List<DemoProduct>> getProducts() async {
    try {
      final List<DemoProductModel> models = await remote.fetchProducts();
      return models.map((m) => m.toEntity()).toList();
    } catch (e) {
      // Keep it simple, but you can map to custom Failure later
      throw Exception('DemoProductRepositoryImpl.getProducts failed: $e');
    }
  }
}

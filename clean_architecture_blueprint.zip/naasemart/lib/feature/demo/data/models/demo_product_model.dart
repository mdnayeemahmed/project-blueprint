import 'package:naasemart/feature/demo/domain/entities/demo_product.dart';

class DemoProductModel {
  final String id;
  final String name;
  final double price;

  const DemoProductModel({
    required this.id,
    required this.name,
    required this.price,
  });

  factory DemoProductModel.fromJson(Map<String, dynamic> json) {
    return DemoProductModel(
      id: json['id']?.toString() ?? '',
      name: json['name']?.toString() ?? '',
      price: _toDouble(json['price']),
    );
  }

  Map<String, dynamic> toJson() => {
    'id': id,
    'name': name,
    'price': price,
  };

  DemoProduct toEntity() => DemoProduct(
    id: id,
    name: name,
    price: price,
  );
}

double _toDouble(dynamic v) {
  if (v == null) return 0.0;
  if (v is num) return v.toDouble();
  return double.tryParse(v.toString()) ?? 0.0;
}
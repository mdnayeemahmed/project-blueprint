import 'package:naasemart/core/network/api_endpoints.dart';
import 'package:naasemart/core/network/network_service.dart';

import '../models/demo_product_model.dart';


abstract class DemoProductRemoteDataSource {
  Future<List<DemoProductModel>> fetchProducts();
}

class DemoProductRemoteDataSourceImpl implements DemoProductRemoteDataSource {
  final NetworkService network;

  DemoProductRemoteDataSourceImpl(this.network);

  @override
  Future<List<DemoProductModel>> fetchProducts() async {
    final res = await network.getRequest(ApiEndpoints.demoProducts);

    if (res.isSuccess != true) {
      throw (res.errorMessage?.trim().isNotEmpty ?? false)
          ? res.errorMessage!
          : 'Failed to load products';
    }

    final data = res.responseData;

    // Case A: direct list
    final listA = _asList(data);
    if (listA != null) return _parseList(listA);

    // Case B: wrapped { data: [...] }  (also supports common keys)
    if (data is Map) {
      final wrapped = _asList(data['data']) ??
          _asList(data['items']) ??
          _asList(data['results']);
      if (wrapped != null) return _parseList(wrapped);
    }

    throw 'Invalid products response format';
  }

  List<dynamic>? _asList(dynamic v) => v is List ? v : null;

  List<DemoProductModel> _parseList(List<dynamic> list) {
    return list
        .where((e) => e is Map)
        .map((e) => DemoProductModel.fromJson(Map<String, dynamic>.from(e as Map)))
        .toList();
  }
}

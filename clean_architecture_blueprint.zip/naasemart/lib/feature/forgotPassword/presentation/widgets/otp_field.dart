import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:naasemart/core/utils/extension.dart';

class OtpField extends StatefulWidget {
  final int length;
  final void Function(String code)? onCompleted;
  final bool hasError; // ✅ controls error border from parent

  const OtpField({
    super.key,
    this.length = 5,
    this.onCompleted,
    this.hasError = false,
  });

  @override
  State<OtpField> createState() => _OtpFieldState();
}

class _OtpFieldState extends State<OtpField> {
  late final List<TextEditingController> controllers;
  late final List<FocusNode> focusNodes;

  @override
  void initState() {
    super.initState();
    controllers = List.generate(widget.length, (_) => TextEditingController());
    focusNodes = List.generate(widget.length, (_) => FocusNode());
  }

  @override
  void dispose() {
    for (final c in controllers) c.dispose();
    for (final f in focusNodes) f.dispose();
    super.dispose();
  }

  void _onChanged(int index, String value) {
    if (value.isNotEmpty) {
      if (index < widget.length - 1) {
        focusNodes[index + 1].requestFocus();
      } else {
        focusNodes[index].unfocus();
      }
    } else if (index > 0) {
      focusNodes[index - 1].requestFocus();
    }

    final code = controllers.map((e) => e.text).join();
    if (code.length == widget.length) {
      widget.onCompleted?.call(code);
    }
  }

  @override
  Widget build(BuildContext context) {
    final primary = context.color.primary;

    final enabledBorder = OutlineInputBorder(
      borderRadius: BorderRadius.circular(8),
      borderSide: BorderSide(color: Colors.grey.shade300),
    );

    final focusedBorder = OutlineInputBorder(
      borderRadius: BorderRadius.circular(8),
      borderSide: BorderSide(color: primary, width: 2),
    );

    final errorBorder = OutlineInputBorder(
      borderRadius: BorderRadius.circular(8),
      borderSide: const BorderSide(color: Colors.red, width: 1.5),
    );

    final focusedErrorBorder = OutlineInputBorder(
      borderRadius: BorderRadius.circular(8),
      borderSide: const BorderSide(color: Colors.red, width: 2),
    );

    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: List.generate(widget.length, (index) {
        return SizedBox(
          width: 60,
          child: TextField(
            controller: controllers[index],
            focusNode: focusNodes[index],
            keyboardType: TextInputType.number,
            textAlign: TextAlign.center,
            maxLength: 1,
            onChanged: (v) => _onChanged(index, v),

            // ✅ digits only + single char
            inputFormatters: [
              FilteringTextInputFormatter.digitsOnly,
              LengthLimitingTextInputFormatter(1),
            ],

            decoration: InputDecoration(
              counterText: "",
              filled: true,
              fillColor: Colors.white,

              enabledBorder: enabledBorder,
              focusedBorder: focusedBorder,

              errorBorder: errorBorder,
              focusedErrorBorder: focusedErrorBorder,

              // ✅ show red border without error text
              errorText: widget.hasError ? "" : null,
            ),
          ),
        );
      }),
    );
  }
}

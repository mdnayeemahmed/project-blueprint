import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:naasemart/core/utils/extension.dart';
import 'package:naasemart/core/widgets/app_bar_widget.dart';
import 'package:naasemart/core/widgets/app_text_input_field.dart';

class CreateNewPasswordScreen extends StatefulWidget {
  static const String name = '/createNewPasswordScreen';

  const CreateNewPasswordScreen({super.key});

  @override
  State<CreateNewPasswordScreen> createState() =>
      _CreateNewPasswordScreenState();
}

class _CreateNewPasswordScreenState extends State<CreateNewPasswordScreen> {
  final TextEditingController passwordController = TextEditingController();
  final TextEditingController confirmPasswordController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    final screenHeight = MediaQuery.of(context).size.height;

    return Scaffold(
      resizeToAvoidBottomInset: true,
      appBar: AppBackTitleBar(
        title: context.strings.createPassword, // ✅ localized
      ),
      body: SingleChildScrollView(
        child: ConstrainedBox(
          constraints: BoxConstraints(
              minHeight: (screenHeight -
                  AppBar().preferredSize.height -
                  MediaQuery.of(context).padding.top) * 0.85),
          child: Padding(
            padding: const EdgeInsets.all(24.0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Text(
                  context.strings.createPassword,
                  style: TextStyle(
                    fontSize: 24.sp,
                    fontWeight: FontWeight.w500,
                    color: context.color.primary,
                  ),
                ),
                SizedBox(height: 5.h),
                Text(
                  context.strings.pleaseCreatePassword,
                  style: TextStyle(
                    fontSize: 12.sp,
                    color: context.color.textSecondary,
                  ),
                ),
             
                SizedBox(height: 30.h),
                AppTextInputField(
                  controller: passwordController,
                  label: context.strings.password,
                  hint: context.strings.hintPassword,
                  obscureText: true,
                  validator: (v) {
                    final value = (v ?? "");
                    if (value.isEmpty) return context.strings.errPasswordRequired;
                    if (value.length < 6) return context.strings.errPasswordMin;
                    return null;
                  },
                ),

                SizedBox(height: 16.h),

                AppTextInputField(
                  controller: confirmPasswordController,
                  label: context.strings.confirmPassword,
                  hint: context.strings.hintConfirmPassword,
                  obscureText: true,
                  validator: (v) {
                    final value = (v ?? "");
                    if (value.isEmpty) return context.strings.errConfirmPasswordRequired;
                    if (value != passwordController.text) return context.strings.errPasswordNotMatch;
                    return null;
                  },
                ),
                SizedBox(height: 20.h),
                SizedBox(
                  width: double.infinity,
                  height: 50.h,
                  child: ElevatedButton(
                    onPressed: () {

                    },
                    child: Text(context.strings.next),
                  ),
                ),
                SizedBox(height: 30.h),

              ],
            ),
          ),
        ),
      ),

    );
  }
}

import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:naasemart/core/utils/extension.dart';
import 'package:naasemart/core/widgets/app_bar_widget.dart';
import 'package:naasemart/feature/forgotPassword/presentation/pages/create_new_password_screen.dart';
import 'package:naasemart/feature/forgotPassword/presentation/widgets/otp_field.dart';

class OtpScreen extends StatefulWidget {
  static const String name = '/otpScreen';

  const OtpScreen({super.key});

  @override
  State<OtpScreen> createState() => _OtpScreenState();
}

class _OtpScreenState extends State<OtpScreen> {

  @override
  Widget build(BuildContext context) {
    final screenHeight = MediaQuery.of(context).size.height;

    return Scaffold(
      resizeToAvoidBottomInset: true,
      appBar: AppBackTitleBar(
        title: context.strings.forgotPassword,
      ),
      body: SingleChildScrollView(
        child: ConstrainedBox(
          constraints: BoxConstraints(
              minHeight: (screenHeight -
                  AppBar().preferredSize.height -
                  MediaQuery.of(context).padding.top) * 0.85),
          child: Padding(
            padding: const EdgeInsets.all(24.0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Text(
                  context.strings.placeOtp,
                  style: TextStyle(
                    fontSize: 24.sp,
                    fontWeight: FontWeight.w500,
                    color: context.color.primary,
                  ),
                ),
                SizedBox(height: 5.h),
                Text(
                  context.strings.pleasePlaceOtp,
                  style: TextStyle(
                    fontSize: 12.sp,
                    color: context.color.textSecondary,
                  ),
                ),
                Text(
                  context.strings.otpSent,
                  style: TextStyle(
                    fontSize: 12.sp,
                    color: context.color.textSecondary,
                  ),
                ),
                SizedBox(height: 30.h),
                OtpField(
                  onCompleted: (code) {
                    print("OTP: $code");
                  },
                ),
                SizedBox(height: 20.h),
                SizedBox(
                  width: double.infinity,
                  height: 50.h,
                  child: ElevatedButton(
                    onPressed: () {
                      Navigator.pushNamed(context, CreateNewPasswordScreen.name);

                    },
                    child: Text(context.strings.next),
                  ),
                ),

              ],
            ),
          ),
        ),
      ),
    );
  }
}

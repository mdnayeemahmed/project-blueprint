import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:naasemart/core/utils/extension.dart';
import 'package:naasemart/core/widgets/app_bar_widget.dart';
import 'package:naasemart/core/widgets/app_text_input_field.dart';
import 'package:naasemart/core/widgets/dash_divider.dart';
import 'package:naasemart/feature/forgotPassword/presentation/pages/otp_screen.dart';

class ForgotPasswordScreen extends StatefulWidget {
  static const String name = '/forgotPasswordScreen';

  const ForgotPasswordScreen({super.key});

  @override
  State<ForgotPasswordScreen> createState() => _ForgotPasswordScreenState();
}

class _ForgotPasswordScreenState extends State<ForgotPasswordScreen> {
  final TextEditingController emailController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    final screenHeight = MediaQuery.of(context).size.height;

    return Scaffold(
      resizeToAvoidBottomInset: true,
      appBar: AppBackTitleBar(
        title: context.strings.forgotPassword,
      ),
      body: SingleChildScrollView(
        child: ConstrainedBox(
          constraints: BoxConstraints(
            minHeight: (screenHeight -
                AppBar().preferredSize.height -
                MediaQuery.of(context).padding.top) * 0.85),
          child: Padding(
            padding: const EdgeInsets.all(24.0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Text(
                  context.strings.forgotPassword,
                  style: TextStyle(
                    fontSize: 24.sp,
                    fontWeight: FontWeight.w500,
                    color: context.color.primary,
                  ),
                ),
                SizedBox(height: 5.h),
                Text(
                  context.strings.pleaseEnterEmail,
                  style: TextStyle(
                    fontSize: 12.sp,
                    color: context.color.textSecondary,
                  ),
                ),
                Text(
                  context.strings.otpWillSent,
                  style: TextStyle(
                    fontSize: 12.sp,
                    color: context.color.textSecondary,
                  ),
                ),
                SizedBox(height: 30.h),
                AppTextInputField(
                  controller: emailController,
                  label: context.strings.yourEmail,
                  hint: context.strings.hintEmail,
                  keyboardType: TextInputType.emailAddress,
                  validator: (v) {
                    final value = (v ?? "").trim();
                    if (value.isEmpty) return context.strings.errEmailRequired;
                    if (!value.contains("@")) return context.strings.errEmailInvalid;
                    return null;
                  },
                ),
                SizedBox(height: 20.h),
                SizedBox(
                  width: double.infinity,
                  height: 50.h,
                  child: ElevatedButton(
                    onPressed: () {
                      Navigator.pushNamed(context, OtpScreen.name);

                    },
                    child: Text(context.strings.next),
                  ),
                ),
                SizedBox(height: 30.h),
                DashedDivider(),
                SizedBox(height: 20.h),
                Text(
                  context.strings.alreadyRememberPassword,
                  style: TextStyle(
                    fontSize: 12.sp,
                    color: context.color.textPrimary,
                    fontWeight: FontWeight.w500,
                  ),
                ),
                GestureDetector(
                  onTap: () {
                    // Navigate back to login
                    Navigator.pop(context);
                  },
                  child: Text(
                    context.strings.login,
                    style: TextStyle(
                      fontSize: 14.sp,
                      color: context.color.primary,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:naasemart/core/storage/shared_preferance.dart';

class LocaleCubit extends Cubit<Locale> {
  final SharedPrefs prefs;

  LocaleCubit(this.prefs) : super(const Locale('en')) {
    _loadSavedLanguage();
  }

  Future<void> _loadSavedLanguage() async {
    final code = (await prefs.getLanguage())?.trim();

    // ✅ If empty or null → default English
    if (code == null || code.isEmpty) {
      await prefs.saveLanguage('en');
      emit(const Locale('en'));
      return;
    }

    emit(Locale(code));
  }

  Future<void> setEnglish() async {
    await prefs.saveLanguage('en');
    emit(const Locale('en'));
  }

  Future<void> setBangla() async {
    await prefs.saveLanguage('bn');
    emit(const Locale('bn'));
  }

  // Optional: set by code (useful for dropdown)
  Future<void> setLocaleCode(String code) async {
    final c = code.trim();
    if (c.isEmpty) return;

    await prefs.saveLanguage(c);
    emit(Locale(c));
  }
}

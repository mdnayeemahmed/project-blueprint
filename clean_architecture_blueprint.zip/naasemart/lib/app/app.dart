import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:naasemart/app/di/injection.dart';
import 'package:naasemart/app/router/app_router.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:naasemart/feature/splash/presentation/pages/splash_screen.dart';
import '../l10n/app_localizations.dart';
import 'theme/app_theme.dart';
import 'localization/locale_cubit.dart';

class App extends StatelessWidget {
  const App({super.key});

  @override
  Widget build(BuildContext context) {
    return ScreenUtilInit(
      designSize: const Size(375, 844),
      minTextAdapt: true,
      splitScreenMode: true,
      ensureScreenSize: true,
      builder: (context, _) {
        return MultiBlocProvider(
          providers: [
            BlocProvider<LocaleCubit>(
              create: (_) => sl<LocaleCubit>(),
            ),

            // ✅ Add other blocs here
            // BlocProvider(create: (_) => sl<AuthBloc>()),
          ],
          child: BlocBuilder<LocaleCubit, Locale>(
            builder: (context, locale) {
              return MaterialApp(
                debugShowCheckedModeBanner: false,

                // ✅ Localization
                locale: locale,
                supportedLocales:  [
                  Locale('en'),
                  Locale('bn'),
                ],
                localizationsDelegates:  [
                  AppLocalizations.delegate,
                  GlobalMaterialLocalizations.delegate,
                  GlobalWidgetsLocalizations.delegate,
                  GlobalCupertinoLocalizations.delegate,
                ],

                // ✅ Theme
                theme: AppTheme.lightThemeData,
                darkTheme: AppTheme.darkThemeData,

                // ✅ Routing
                home: const SplashScreen(),
                onGenerateRoute: onGenerateRoute,
              );
            },
          ),
        );
      },
    );
  }

}


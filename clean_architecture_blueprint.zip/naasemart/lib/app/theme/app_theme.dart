import 'package:flutter/material.dart';
import '../../core/constants/app_colors.dart';

class AppTheme {
  static ThemeData light(BuildContext context) {
    final c = AppColor(context);

    return ThemeData(
      brightness: Brightness.light,
      scaffoldBackgroundColor: c.background,

      colorScheme: ColorScheme.light(
        primary: c.primary,
        surface: c.card,
      ),

      filledButtonTheme: FilledButtonThemeData(
        style: FilledButton.styleFrom(
          backgroundColor: c.primary,
          fixedSize: const Size.fromWidth(double.maxFinite),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
          ),
        ),
      ),

      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor: c.primary,
          foregroundColor: Colors.white,
        ),
      ),

      inputDecorationTheme: InputDecorationTheme(
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
        ),
      ),
    );
  }

  static ThemeData dark(BuildContext context) {
    final c = AppColor(context);

    return ThemeData(
      brightness: Brightness.dark,
      scaffoldBackgroundColor: c.background,

      colorScheme: ColorScheme.dark(
        primary: c.primary,
        surface: c.card,
      ),
    );
  }
}

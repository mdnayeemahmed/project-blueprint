import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:naasemart/core/utils/extension.dart';
import '../../core/constants/app_colors.dart';

class AppTheme {
  static ThemeData light(BuildContext context) {
    final c = context.color; // ✅ extension

    return ThemeData(
      brightness: Brightness.light,
      scaffoldBackgroundColor: c.background,

      colorScheme: ColorScheme.light(
        primary: c.primary,
        surface: c.card,
      ),

      filledButtonTheme: FilledButtonThemeData(
        style: FilledButton.styleFrom(
          backgroundColor: c.primary,
          fixedSize: const Size.fromWidth(double.maxFinite),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(8),
          ),
        ),
      ),

      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor: c.primary,
          foregroundColor: Colors.white,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(8),
          ),
          textStyle:  TextStyle(
            fontWeight: FontWeight.w500,
            fontSize: 14.sp,
            height: 1.0, // line-height 100%
            letterSpacing: 0,
          ),
        ),
      ),

      inputDecorationTheme: const InputDecorationTheme(
        filled: true,
        fillColor: Colors.white,
        hintStyle: TextStyle(
          color: Color(0xFFC9C9C9),
        ),

        border: OutlineInputBorder(
          borderRadius: BorderRadius.all(Radius.circular(16)),
          borderSide: BorderSide(
            color: Color(0xFFBDBDBD), // gray border
          ),
        ),

        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.all(Radius.circular(16)),
          borderSide: BorderSide(
            color: Color(0xFFBDBDBD),
          ),
        ),

        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.all(Radius.circular(16)),
          borderSide: BorderSide(
            color: Color(0xFF9E9E9E), // darker gray when focused
            width: 1.5,
          ),
        ),
      ),
        );
  }

  static ThemeData dark(BuildContext context) {
    final c = context.color; // ✅ extension

    return ThemeData(
      brightness: Brightness.dark,
      scaffoldBackgroundColor: c.background,

      colorScheme: ColorScheme.dark(
        primary: c.primary,
        surface: c.card,
      ),
    );
  }
}

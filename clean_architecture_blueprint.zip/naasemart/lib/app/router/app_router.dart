import 'package:flutter/material.dart';
import 'package:naasemart/feature/splash/presentation/pages/splash_screen.dart';

Route<dynamic> onGenerateRoute(RouteSettings settings) {
  switch (settings.name) {
    case SplashScreen.name:
      return MaterialPageRoute(builder: (_) => const SplashScreen());

    default:
      return _errorRoute('No route defined for ${settings.name}');
  }
}

Route<dynamic> _errorRoute(String message) {
  return MaterialPageRoute(
    builder: (_) => Scaffold(
      appBar: AppBar(title: const Text('Route Error')),
      body: Center(child: Text(message)),
    ),
  );
}

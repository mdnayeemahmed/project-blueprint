import 'package:flutter/material.dart';
import 'package:naasemart/feature/forgotPassword/presentation/pages/create_new_password_screen.dart';
import 'package:naasemart/feature/forgotPassword/presentation/pages/forgot_password_screen.dart';
import 'package:naasemart/feature/forgotPassword/presentation/pages/otp_screen.dart';
import 'package:naasemart/feature/login/presentation/pages/login_screen.dart';
import 'package:naasemart/feature/signup/presentation/pages/sign_up_screen.dart';
import 'package:naasemart/feature/splash/presentation/pages/splash_screen.dart';

Route<dynamic> onGenerateRoute(RouteSettings settings) {
  switch (settings.name) {
    case SplashScreen.name:
      return MaterialPageRoute(builder: (_) => const SplashScreen());
    case LoginScreen.name:
      return MaterialPageRoute(builder: (_) => const LoginScreen());
    case SignUpScreen.name:
      return MaterialPageRoute(builder: (_) => const SignUpScreen());
    case ForgotPasswordScreen.name:
      return MaterialPageRoute(builder: (_) => const ForgotPasswordScreen());
    case CreateNewPasswordScreen.name:
      return MaterialPageRoute(builder: (_) => const CreateNewPasswordScreen());
    case OtpScreen.name:
      return MaterialPageRoute(builder: (_) => const OtpScreen());

    default:
      return _errorRoute('No route defined for ${settings.name}');
  }
}

Route<dynamic> _errorRoute(String message) {
  return MaterialPageRoute(
    builder: (_) => Scaffold(
      appBar: AppBar(title: const Text('Route Error')),
      body: Center(child: Text(message)),
    ),
  );
}

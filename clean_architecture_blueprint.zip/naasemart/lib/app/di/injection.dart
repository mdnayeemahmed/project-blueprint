import 'package:get_it/get_it.dart';
import 'package:naasemart/app/localization/locale_cubit.dart';

import 'package:naasemart/core/network/network_service.dart';
import 'package:naasemart/core/storage/shared_preferance.dart';

import 'package:naasemart/feature/demo/data/datasource/demo_product_remote_datasource.dart';
import 'package:naasemart/feature/demo/data/repository/demo_product_repository_impl.dart';
import 'package:naasemart/feature/demo/domain/repository/demo_product_repository.dart';
import 'package:naasemart/feature/demo/domain/usecases/get_demo_products_usecase.dart';
import 'package:naasemart/feature/demo/presentation/bloc/demo_product_bloc.dart';

final sl = GetIt.instance;

Future<void> initInjection() async {

  // ===============================
  // 1. NETWORK LAYER
  // ===============================
  // This is the base service that handles API calls.
  // Only one instance is created and shared everywhere.
  // LazySingleton = created only when first used.
  sl.registerLazySingleton<NetworkService>(
        () => NetworkService(),
  );

  sl.registerLazySingleton<SharedPrefs>(
        () => SharedPrefs(),
  );


  // ===============================
  // 2. DATA SOURCE LAYER
  // ===============================
  // DataSource talks directly to the API.
  // It depends on NetworkService.
  // sl() automatically gives the registered NetworkService.
  sl.registerLazySingleton<DemoProductRemoteDataSource>(
        () => DemoProductRemoteDataSourceImpl(sl()),
  );


  // ===============================
  // 3. REPOSITORY LAYER
  // ===============================
  // Repository converts raw API data into clean domain models.
  // It depends on DataSource.
  sl.registerLazySingleton<DemoProductRepository>(
        () => DemoProductRepositoryImpl(sl()),
  );


  // ===============================
  // 4. USE CASE LAYER
  // ===============================
  // UseCase contains business logic.
  // UI should talk to UseCase, not directly to Repository.
  sl.registerLazySingleton<GetDemoProductsUseCase>(
        () => GetDemoProductsUseCase(sl()),
  );


  // ===============================
  // 5. BLOC (UI STATE LAYER)
  // ===============================
  // Bloc handles UI state.
  // Factory = new Bloc instance every time a screen opens.
  sl.registerFactory<DemoProductBloc>(
        () => DemoProductBloc(sl()),
  );

  sl.registerFactory<LocaleCubit>(
        () => LocaleCubit(sl()),
  );
}

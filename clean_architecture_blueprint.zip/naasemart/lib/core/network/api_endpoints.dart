class ApiEndpoints {
  // auth
  static const login = '/auth/login';
  static const register = '/auth/register';
  static const refresh = '/auth/refresh';

  // user
  static const profile = '/user/profile';

  // products
  static const products = '/products';
  static const demoProducts = '/products';
  static const productDetails = '/products/details';

  // cart
  static const cart = '/cart';

  // orders
  static const orders = '/orders';
}

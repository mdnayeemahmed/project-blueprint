import 'package:flutter/foundation.dart';

final ValueNotifier<bool> agreeNotifier = ValueNotifier(false);

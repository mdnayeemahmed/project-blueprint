import 'dart:ui';

import 'package:flutter/material.dart';

import 'package:flutter/material.dart';

import 'package:flutter/material.dart';

class AppColor {
  const AppColor(this.context);
  final BuildContext context;

  bool get isDarkMode =>
      Theme.of(context).brightness == Brightness.dark;

  // ---------------- Primary brand color ----------------
  Color get primary => const Color(0xFF95C43F); // #95C43F

  // ---------------- Dark accent background ----------------
  Color get blackBackground => const Color(0xFF165522); // #165522

  // ---------------- Dynamic backgrounds ----------------
  Color get background =>
      isDarkMode ? const Color(0xFF000000) : const Color(0xFFF5FAED);


  // Optional surface/card background
  Color get card =>
      isDarkMode ? const Color(0xFF0A220C) : Colors.white;

  // ---------------- Text colors ----------------
  Color get textPrimary =>
      isDarkMode ? Colors.white : const Color(0xFF1A1A1A);

  Color get textSecondary =>
      isDarkMode ? const Color(0xB3FFFFFF) : const Color(0xFF6F727C);

}


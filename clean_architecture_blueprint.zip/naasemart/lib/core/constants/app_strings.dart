import 'package:flutter/widgets.dart';
import 'package:naasemart/l10n/app_localizations.dart';

class AppStrings {
  final BuildContext context;

  AppStrings(this.context);

  AppLocalizations get _l10n => AppLocalizations.of(context)!;

  String get demoProductsTitle => _l10n.demoProductsTitle;
  String get loadProducts => _l10n.loadProducts;
  String get noProducts => _l10n.noProducts;
  String get retry => _l10n.retry;
}

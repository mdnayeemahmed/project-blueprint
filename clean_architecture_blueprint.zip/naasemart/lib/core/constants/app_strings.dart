import 'package:flutter/widgets.dart';
import 'package:naasemart/core/utils/extension.dart';
import 'package:naasemart/l10n/app_localizations.dart';

class AppStrings {
  final BuildContext context;
  const AppStrings(this.context);

  AppLocalizations get _l10n => context.l10n;


  String get helloThere => _l10n.helloThere;
  String get loginSubtitle => _l10n.loginSubtitle;
  String get email => _l10n.email;
  String get password => _l10n.password;
  String get forgotPassword => _l10n.forgotPassword;
  String get login => _l10n.login;
  String get newHere => _l10n.newHere;
  String get signUp => _l10n.signUp;
  String get firstName => _l10n.firstName;
  String get lastName => _l10n.lastName;
  String get confirmPassword => _l10n.confirmPassword;
  String get createPassword => _l10n.createPassword;
  String get pleaseCreatePassword => _l10n.pleaseCreatePassword;
  String get placeOtp => _l10n.placeOtp;
  String get pleasePlaceOtp => _l10n.pleasePlaceOtp;
  String get otpSent => _l10n.otpSent;
  String get pleaseEnterEmail => _l10n.pleaseEnterEmail;
  String get otpWillSent => _l10n.otpWillSent;
  String get next => _l10n.next;
  String get alreadyRememberPassword => _l10n.alreadyRememberPassword;
  String get yourEmail => _l10n.yourEmail;



  String get demoProductsTitle => _l10n.demoProductsTitle;
  String get loadProducts => _l10n.loadProducts;
  String get noProducts => _l10n.noProducts;
  String get retry => _l10n.retry;
  String copyright(int year) => _l10n.copyright(year);

  // ✅ Hints
  String get hintFirstName => _l10n.hintFirstName;
  String get hintLastName => _l10n.hintLastName;
  String get hintEmail => _l10n.hintEmail;
  String get hintPassword => _l10n.hintPassword;
  String get hintConfirmPassword => _l10n.hintConfirmPassword;

  // ✅ Errors
  String get errFirstNameRequired => _l10n.errFirstNameRequired;
  String get errLastNameRequired => _l10n.errLastNameRequired;
  String get errEmailRequired => _l10n.errEmailRequired;
  String get errEmailInvalid => _l10n.errEmailInvalid;
  String get errPasswordRequired => _l10n.errPasswordRequired;
  String get errPasswordMin => _l10n.errPasswordMin;
  String get errConfirmPasswordRequired => _l10n.errConfirmPasswordRequired;
  String get errPasswordNotMatch => _l10n.errPasswordNotMatch;
  String get agreePrefix => _l10n.agreePrefix;
  String get termsOfService => _l10n.termsOfService;
  String get alreadyHaveAccount => _l10n.alreadyHaveAccount;

}

import 'package:flutter/material.dart';
import '../constants/app_colors.dart';

class AppSnackbar {
  static void success(BuildContext context, String message) {
    _show(
      context,
      message,
      AppColors.success,
      Icons.check_circle_outline,
    );
  }

  static void error(BuildContext context, String message) {
    _show(
      context,
      message,
      AppColors.error,
      Icons.error_outline,
    );
  }

  static void warning(BuildContext context, String message) {
    _show(
      context,
      message,
      AppColors.warning,
      Icons.warning_amber_outlined,
    );
  }

  static void info(BuildContext context, String message) {
    _show(
      context,
      message,
      AppColors.info,
      Icons.info_outline,
    );
  }

  static void _show(
      BuildContext context,
      String message,
      Color color,
      IconData icon,
      ) {
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(
        SnackBar(
          behavior: SnackBarBehavior.floating,
          backgroundColor: color,
          margin: const EdgeInsets.all(16),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
          content: Row(
            children: [
              Icon(icon, color: Colors.white),
              const SizedBox(width: 12),
              Expanded(
                child: Text(
                  message,
                  style: const TextStyle(color: Colors.white),
                ),
              ),
            ],
          ),
        ),
      );
  }
}

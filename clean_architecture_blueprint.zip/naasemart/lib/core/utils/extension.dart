import 'package:flutter/material.dart';
import 'package:naasemart/core/constants/app_colors.dart';
import 'package:naasemart/core/constants/app_strings.dart';
import '../../l10n/app_localizations.dart';

extension ContextX on BuildContext {
  AppLocalizations get l10n => AppLocalizations.of(this)!;

  AppColor get color => AppColor(this);

  AppStrings get strings => AppStrings(this);
}

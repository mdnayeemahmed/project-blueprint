import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';
class SharedPrefs {
  // KEYS
  static const _kAccess = 'token';
  static const _kRefreshToken = 'refresh_token';
  static const _kUser = 'user';
  static const _kUserId = 'user_id';
  static const _kTypeSpecificId = 'type_specific_id';
  static const _kBookingId = 'booking_id';
  static const _kLanguage = 'app_language';
  static const String _kLastShownNotifId = 'last_shown_notif_id';

  // optional legacy keys you had
  static const accessToken = 'access_token';
  static const tokenType = 'token_type';
  static const patientId = 'patient_id';
  static const patientProfile = 'patient_profile_json';
  static const isLoggedIn = 'is_logged_in';
  static const lastPhone = 'last_phone';

  // In-memory cache for sync header usage
  static String? _cachedToken;

  // Internal helper: reuse prefs instance
  static Future<SharedPreferences> _prefs() => SharedPreferences.getInstance();

  // -------- TOKEN --------
  static String? get tokenSync => _cachedToken;

  Future<void> saveToken(String token) async {
    final p = await _prefs();
    await p.setString(_kAccess, token);
    _cachedToken = token;
  }

  Future<String?> getToken() async {
    final p = await _prefs();
    final t = p.getString(_kAccess);
    _cachedToken = t; // ✅ prime cache
    return t;
  }

  Future<void> removeToken() async {
    final p = await _prefs();
    await p.remove(_kAccess);
    _cachedToken = null;
  }

  // -------- REFRESH TOKEN --------
  Future<void> saveRefreshToken(String refreshToken) async {
    final p = await _prefs();
    await p.setString(_kRefreshToken, refreshToken);
  }

  Future<String?> getRefreshToken() async {
    final p = await _prefs();
    return p.getString(_kRefreshToken);
  }

  Future<void> removeRefreshToken() async {
    final p = await _prefs();
    await p.remove(_kRefreshToken);
  }

  // -------- LANGUAGE --------
  Future<void> saveLanguage(String code) async {
    final p = await _prefs();
    await p.setString(_kLanguage, code); // 'en', 'so'
  }

  Future<String?> getLanguage() async {
    final p = await _prefs();
    return p.getString(_kLanguage);
  }

  // -------- GENERIC --------
  Future<void> setString(String key, String value) async {
    final p = await _prefs();
    await p.setString(key, value);
  }

  Future<String?> getString(String key) async {
    final p = await _prefs();
    return p.getString(key);
  }

  Future<void> setBool(String key, bool value) async {
    final p = await _prefs();
    await p.setBool(key, value);
  }

  Future<bool?> getBool(String key) async {
    final p = await _prefs();
    return p.getBool(key);
  }

  Future<void> setInt(String key, int value) async {
    final p = await _prefs();
    await p.setInt(key, value);
  }

  Future<int?> getInt(String key) async {
    final p = await _prefs();
    return p.getInt(key);
  }

  // -------- BOOKING ID --------
  Future<void> saveBookingID(int booking) async {
    final p = await _prefs();
    await p.setInt(_kBookingId, booking);
  }

  Future<int?> getBookingID() async {
    final p = await _prefs();
    return p.getInt(_kBookingId);
  }

  // -------- USER --------
  Future<void> saveUserId(String? userId) async {
    final s = (userId ?? '').trim();
    if (s.isEmpty) return;
    final p = await _prefs();
    await p.setString(_kUserId, s);
  }

  Future<String?> getUserId() async {
    final p = await _prefs();
    return p.getString(_kUserId);
  }

  Future<void> saveTypeSpecificId(String? typeSpecificId) async {
    final s = (typeSpecificId ?? '').trim();
    if (s.isEmpty) return;
    final p = await _prefs();
    await p.setString(_kTypeSpecificId, s);
  }

  Future<String?> getTypeSpecificId() async {
    final p = await _prefs();
    return p.getString(_kTypeSpecificId);
  }

  Future<void> saveUser(Map<String, dynamic> user) async {
    final p = await _prefs();
    await p.setString(_kUser, jsonEncode(user));
  }

  Future<Map<String, dynamic>?> getUser() async {
    final p = await _prefs();
    final s = p.getString(_kUser);
    if (s == null || s.trim().isEmpty) return null;
    try {
      return jsonDecode(s) as Map<String, dynamic>;
    } catch (_) {
      return null;
    }
  }

  Future<void> removeUser() async {
    final p = await _prefs();
    await p.remove(_kUser);
  }

  // -------- CLEAR ALL --------
  static Future<void> clearAll() async {
    final p = await _prefs();
    await p.clear();
    _cachedToken = null;


  }

}

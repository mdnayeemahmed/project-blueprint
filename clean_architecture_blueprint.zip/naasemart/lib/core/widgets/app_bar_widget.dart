import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

class AppBackTitleBar extends StatelessWidget implements PreferredSizeWidget {
  final String title;
  final VoidCallback? onBack;

  const AppBackTitleBar({
    super.key,
    required this.title,
    this.onBack,
  });

  static const double _height = 48; // ✅ smaller height

  @override
  Size get preferredSize => Size.fromHeight(_height.h);

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.white,
      elevation: 1,
      child: SafeArea(
        bottom: false,
        child: SizedBox(
          height: _height.h,
          child: Padding(
            padding: EdgeInsets.symmetric(horizontal: 12.w), // tighter padding
            child: Row(
              children: [
                InkWell(
                  borderRadius: BorderRadius.circular(8.r),
                  onTap: onBack ?? () => Navigator.pop(context),
                  child: Padding(
                    padding: EdgeInsets.all(6.r), // smaller tap area
                    child: Icon(
                      Icons.arrow_back_ios_new,
                      size: 16.sp, // smaller icon
                      color: Colors.black87,
                    ),
                  ),
                ),
                SizedBox(width: 6.w),
                Text(
                  title,
                  style: TextStyle(
                    fontSize: 16.sp, // smaller text
                    fontWeight: FontWeight.w500,
                    color: Colors.black87,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

import 'package:flutter/material.dart';
import 'package:naasemart/app/app.dart';
import 'package:naasemart/app/di/injection.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await initInjection();
  runApp(const App());
}


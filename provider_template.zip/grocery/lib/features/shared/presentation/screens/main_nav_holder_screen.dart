
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../../app/app_colors.dart';
import '../../../../app/controllers/auth_controller.dart';
import '../../../auth/presentation/screens/sign_in_screen.dart';

import '../providers/main_nav_provider.dart';

class MainNavHolderScreen extends StatefulWidget {
  const MainNavHolderScreen({super.key});

  static const String name = '/main-nav-holder';

  @override
  State<MainNavHolderScreen> createState() => _MainNavHolderScreenState();
}

class _MainNavHolderScreenState extends State<MainNavHolderScreen> {
  final List<Widget> _screens = [
    Container(),
    Container(),
    Container(),
    Container(),
    // HomeScreen(),
    // CategoryListScreen(),
    // CartScreen(),
    // WishListScreen(),
  ];

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      // context.read<HomeSliderProvider>().getHomeSliders();
      // context.read<CategoryListProvider>().getCategories();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Consumer<MainNavProvider>(
      builder: (context, mainNavProvider, _) {
        return Scaffold(
          body: _screens[mainNavProvider.selectedIndex],
          bottomNavigationBar: BottomNavigationBar(
            selectedItemColor: AppColors.themeColor,
            unselectedItemColor: Colors.grey,
            showUnselectedLabels: true,
            onTap: (int index) async {
              if (mainNavProvider.shouldCheckIfUserLoggedIn(index)) {
                final isLoggedIn = await AuthController.isLoggedIn();
                if (isLoggedIn == false) {
                  Navigator.pushNamed(context, SignInScreen.name);
                  return;
                }
              }
              mainNavProvider.setIndex(index);
            },
            currentIndex: mainNavProvider.selectedIndex,
            items: [
              BottomNavigationBarItem(icon: Icon(Icons.home), label: 'Home'),
              BottomNavigationBarItem(
                icon: Icon(Icons.dashboard),
                label: 'Categories',
              ),
              BottomNavigationBarItem(
                icon: Icon(Icons.shopping_cart),
                label: 'Carts',
              ),
              BottomNavigationBarItem(
                icon: Icon(Icons.favorite_outline),
                label: 'Wishlist',
              ),
            ],
          ),
        );
      }
    );
  }
}

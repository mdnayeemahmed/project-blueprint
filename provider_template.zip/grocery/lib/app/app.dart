import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:grocery/app/providers/localization_provider.dart';
import 'package:grocery/app/providers/theme_provider.dart';
import 'package:provider/provider.dart';
import '../l10n/app_localizations.dart';
import 'app_theme.dart';
import 'routes.dart';

class App extends StatelessWidget {
  const App({super.key});

  static GlobalKey<NavigatorState> navigatorKey = GlobalKey<NavigatorState>();

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(
          create: (_) => LocalizationProvider()..loadLocale(),
        ),
        ChangeNotifierProvider(create: (_) =>
        ThemeProvider()
          ..loadThemeMode()),
        // ChangeNotifierProvider(create: (_) => MainNavProvider()),
        // ChangeNotifierProvider(create: (_) => HomeSliderProvider()),
        // ChangeNotifierProvider(create: (_) => CategoryListProvider()),
      ],
      child: Consumer<LocalizationProvider>(
        builder: (context, localizationProvider, _) {
          return Consumer<ThemeProvider>(
            builder: (context, themeProvider, _) {
              return MaterialApp(
                title: 'Crafty Bay',
                navigatorKey: navigatorKey,
                // initialRoute: SplashScreen.name,
                // onGenerateRoute: Routes.onGenerateRoute,
                theme: AppTheme.lightTheme,
                darkTheme: AppTheme.darkTheme,
                themeMode: themeProvider.themeMode,
                localizationsDelegates: [
                  AppLocalizations.delegate,
                  GlobalMaterialLocalizations.delegate,
                  GlobalWidgetsLocalizations.delegate,
                  GlobalCupertinoLocalizations.delegate,
                ],
                supportedLocales: localizationProvider.supportedLocales,
                locale: localizationProvider.locale,
              );
            }
          );
        },
      ),
    );
  }
}

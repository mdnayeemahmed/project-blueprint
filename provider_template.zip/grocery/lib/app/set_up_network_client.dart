// Best Practice => Service Locator/Dependency Injection Manager



import '../core/network_caller/network_caller.dart';
import '../features/auth/presentation/screens/sign_in_screen.dart';
import 'app.dart';
import 'controllers/auth_controller.dart';

NetworkCaller getNetworkCaller() {
  return NetworkCaller(
    headers: () {
      final headers = {'Content-Type': 'application/json'};

      if (AuthController.accessToken != null) {
        headers['token'] = '${AuthController.accessToken}';
      }

      return headers;
    },
    onUnauthorize: () async {
      // Logout from app
      await AuthController.clearUserData();
      App.navigatorKey.currentState!.pushNamed(SignInScreen.name);
    },
  );
}

// USES => getNetworkCaller().getRequest()
